import numpy as np
import os
import glob
from tqdm import tqdm

def generate_face_stats(data_dir, output_dir):
    """
    주어진 디렉터리의 모든 .npy 파일로부터 평균과 표준편차를 계산하고 저장합니다.

    Args:
        data_dir (str): 3D 데이터(.npy)가 들어있는 폴더 경로.
        output_dir (str): 결과 파일을 저장할 폴더 경로.
    """
    data_dir = "/home/ivpl-d35/dataset/AvaMERG/video_v5_0"
    print(f"데이터를 검색할 폴더: {data_dir}")
    
    # 해당 폴더의 모든 .npy 파일 목록을 가져옵니다.
    file_list = glob.glob(os.path.join(data_dir, '*.npy'))
    
    if not file_list:
        print(f"오류: '{data_dir}' 폴더에서 .npy 파일을 찾을 수 없습니다. 경로를 확인해주세요.")
        return

    print(f"총 {len(file_list)}개의 파일에서 통계치를 계산합니다.")

    all_data = []
    
    # 모든 파일을 순회하며 데이터를 리스트에 추가합니다.
    for file_path in tqdm(file_list, desc="파일 로딩 중"):
        try:
            data = np.load(file_path)
            # 데이터의 형태가 (프레임 수, 특징 차원)이라고 가정합니다.
            if data.ndim == 2:
                all_data.append(data)
        except Exception as e:
            print(f"파일 로딩 오류 {file_path}: {e}")

    # 모든 데이터를 하나의 거대한 numpy 배열로 합칩니다.
    # axis=0은 시간(프레임) 축을 기준으로 합치는 것을 의미합니다.
    full_dataset = np.concatenate(all_data, axis=0)
    print(f"전체 데이터 형태: {full_dataset.shape}") # (전체 프레임 수, 특징 차원)

    # 평균(mean)과 표준편차(std)를 계산합니다.
    # axis=0은 각 특징(세로축)에 대한 통계를 계산하는 것을 의미합니다.
    mean_face = np.mean(full_dataset, axis=0)
    std_face = np.std(full_dataset, axis=0)
    
    print(f"계산된 평균 벡터 형태: {mean_face.shape}")
    print(f"계산된 표준편차 벡터 형태: {std_face.shape}")

    # 결과를 저장할 폴더 생성
    os.makedirs(output_dir, exist_ok=True)
    
    # 파일로 저장
    mean_file_path = os.path.join(output_dir, 'mean_face.npy')
    std_file_path = os.path.join(output_dir, 'std_face.npy')
    
    np.save(mean_file_path, mean_face)
    np.save(std_file_path, std_face)

    print(f"\n완료! 파일이 아래 경로에 저장되었습니다:")
    print(f"  - {mean_file_path}")
    print(f"  - {std_file_path}")


if __name__ == '__main__':
    # ‼️ 3D 정점 데이터(3DMM 또는 Vertices)가 있는 실제 폴더 경로를 지정해주세요.
    # 이 경로는 AvaMERGE 데이터셋의 'train' 스플릿에 해당하는 데이터 폴더여야 합니다.
    VERTEX_DATA_DIRECTORY = "/home/ivpl-d35/dataset/AvaMERG/3DMM_train" 
    
    # 생성된 파일을 저장할 경로 (ReactFace 프로젝트 내부)
    OUTPUT_DIRECTORY = "external/FaceVerse"
    
    generate_face_stats(VERTEX_DATA_DIRECTORY, OUTPUT_DIRECTORY)