# generate_landmarks.py
import cv2
import mediapipe as mp
import numpy as np
import os
import glob
from tqdm import tqdm
import argparse

def process_videos(video_dir, output_dir):
    """지정된 디렉토리의 모든 비디오에서 얼굴 랜드마크를 추출합니다."""
    
    # MediaPipe 얼굴 메쉬 모델 초기화
    mp_face_mesh = mp.solutions.face_mesh
    face_mesh = mp_face_mesh.FaceMesh(static_image_mode=False, max_num_faces=1, min_detection_confidence=0.5)

    os.makedirs(output_dir, exist_ok=True)
    
    # ‼️ 비디오 파일 확장자에 맞게 수정 (.mp4, .avi 등)
    video_files = glob.glob(os.path.join(video_dir, '*.mp4'))
    
    if not video_files:
        print(f"오류: '{video_dir}' 에서 비디오 파일을 찾을 수 없습니다.")
        return

    print(f"총 {len(video_files)}개의 비디오 파일을 처리합니다.")

    for video_path in tqdm(video_files, desc="랜드마크 추출 중"):
        cap = cv2.VideoCapture(video_path)
        all_landmarks = []

        while cap.isOpened():
            success, image = cap.read()
            if not success:
                break
            
            # MediaPipe 처리를 위해 BGR 이미지를 RGB로 변환
            image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            results = face_mesh.process(image_rgb)

            if results.multi_face_landmarks:
                face_landmarks = results.multi_face_landmarks[0]
                landmarks_np = np.array([[lm.x, lm.y] for lm in face_landmarks.landmark])
                all_landmarks.append(landmarks_np)
            else:
                # 얼굴이 검출되지 않으면 0으로 채운 배열 추가 (478은 MediaPipe의 랜드마크 개수)
                all_landmarks.append(np.zeros((478, 2)))
        
        cap.release()
        
        # 비디오의 모든 프레임에 대한 랜드마크를 numpy 배열로 변환
        final_landmarks = np.array(all_landmarks)
        
        # 파일 저장
        base_name = os.path.splitext(os.path.basename(video_path))[0]
        output_path = os.path.join(output_dir, f"{base_name}.npy")
        np.save(output_path, final_landmarks)
        
    face_mesh.close()
    print("모든 비디오의 랜드마크 추출이 완료되었습니다.")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='비디오에서 얼굴 랜드마크를 추출합니다.')
    parser.add_argument('--input_dir', type=str, required=True, help='입력 비디오 파일이 있는 디렉토리 경로')
    parser.add_argument('--output_dir', type=str, required=True, help='추출된 .npy 파일을 저장할 디렉토리 경로')
    args = parser.parse_args()
    
    process_videos(args.input_dir, args.output_dir)